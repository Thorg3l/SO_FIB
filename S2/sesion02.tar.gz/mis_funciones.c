#include "mis_funciones.h"
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#define MAX_SIZE 8

int product(int length) {
    int ret = 1;
    for (int i = 1; i < length; ++i) ret *= 10;
    return ret;
}

unsigned int char2int(char c) {
    return c-'0';
}

int mi_atoi(char *s) {
    int num = 0;
    int length = strlen(s);
    int neg = 0;
    if (*s == '-') neg = 1;
    int prod = product(length);
    if (neg != 1) num += char2int(*s)*prod;
    prod /= 10;
    ++s;
    for (int i = 1; i < length; ++i) {
        num += char2int(*s)*prod;
        prod /= 10;
	++s;
    }
    if (neg == 1) num *= -1;
    return num;
}

int esNumero(char *str) {
    int length = strlen(str);
    if (*str == '-') {
        ++str;
        --length;
    }
    if (length > MAX_SIZE) return 0;
    while (*str != '\0') {
        if (*str < '0' || *str > '9') return 0;
        ++str;
    }
    return 1;
}

int usage(int argc, char* buff) {
    if (argc <= 2) {
	sprintf(buff, "Este programa escribe por su salida la suma de los argumentos que recibe\n");
	return -1;
    }
    return 0;
}

