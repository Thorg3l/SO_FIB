#include <stdio.h>
#include <unistd.h>
#include <string.h>

int usage(int argc, char* buff) {
    if (argc <= 1) {
	sprintf(buff, "Este programa cuenta el número de palabras que hay en el string pasado como primer parámetro.\n");
	return -1;
    }
    return 0;
}

int main(int argc, char* argv[]) {
    char buff[100];
    if(usage(argc,buff) == 0) {
        int len = strlen(argv[1]);
        char* p = argv[1];
	int counter = 1;
	int i = 0;
        int end = 0;
	while (i < len) {
            if (*p == ' ' || *p == '.' || *p == ',') ++counter;
	    ++i;	
        }
	sprintf(buff, "%d\n", counter);
    }
    write(1, buff, strlen(buff));
    return 0;
}

