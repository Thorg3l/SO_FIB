#ifndef FUNC
#define FUNC

int product(int length);
unsigned int char2int(char c);
int mi_atoi(char *s);
int esNumero(char *str);
int usage(int argc, char* buff);

#endif 
