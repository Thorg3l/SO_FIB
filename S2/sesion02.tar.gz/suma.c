#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include "mis_funciones.h"

#define MAX_SIZE 8

int main (int argc, char *argv[]) {
    char buff[100];
    if (usage(argc, buff) == 0) {
	int x = 1;
        int j = 1;
	while (j < argc && x == 1) {
	    x = esNumero(argv[j]);
	    ++j;
	}
	if (x == 0) sprintf(buff, "El parámetro %s no es un número\n", argv[j-1]);
	else {
	    int sum = 0;
	    for (int i = 1; i < argc; ++i) sum += mi_atoi(argv[i]);
	    sprintf(buff, "%d\n", sum);	
	}
    }
    write(1, buff, strlen(buff));
    return 0;
}
