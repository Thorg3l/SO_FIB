#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
	int fd = open("./pipo", O_WRONLY);
	if (fd < 0) {
		perror("Open\n");
		exit(1);
	}
	char buff[256];
	int ret = read(0, buff, sizeof(buff));
	while(ret > 0) {
		if (write(fd, buff, ret) < 0) {
			perror("Write\n");
			exit(1);
		}
		ret = read(0, buff, sizeof(buff));
	}	
	if (ret < 0) {
		perror("Read\n");
		exit(1);
	}
	if (close(fd) < 0) {
		perror("Close\n");
		exit(1);
	}
	exit(0);
}
