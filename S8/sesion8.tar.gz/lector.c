#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
	int fd = open("./pipo", O_RDONLY);
	if (fd < 0) {
		perror("Open\n");
		exit(1);
	}
	char buff[256];
	int ret = read(fd, buff, sizeof(buff));
	while(ret > 0) {
		if (write(1, buff, ret) < 0) {
			perror("Write\n");
			exit(1);
		}
		ret = read(fd, buff, sizeof(buff));
	}	
	if (ret < 0) {
		perror("Read\n");
		exit(1);
	}
	if (close(fd) < 0) {
		perror("Close\n");
		exit(1);
	}
	exit(0);
}
