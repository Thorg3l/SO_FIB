#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	int pipefd[2]; //0 -> read, 1 -> write
	if (pipe(pipefd) < 0) {
		perror("Pipe\n");
		exit(1);
	}
	int pid = fork();
	if (pid < 0) {
		perror("Fork\n");
		exit(1);
	}
	else if (pid == 0) {
	//Children
		if (close(pipefd[1]) < 0) {
			perror("Close\n");
			exit(1);
		}
		if (close(0) < 0) {
			perror("Close\n");
			exit(1);
		}
		if (dup(pipefd[0]) < 0) {
			perror("Dup\n");
			exit(1);
		}
		if (close(pipefd[0]) < 0) {
			perror("Close\n");
			exit(1);
		}
		execlp("cat", "cat", (char*)NULL);
		perror("Exec\n");
		exit(1);
	}
	else {
		if (close(pipefd[0]) < 0) {
			perror("Close\n");
			exit(1);
		}
		if (write(pipefd[1], "Inicio\n", 8) < 0) {
			perror("Write\n");
			exit(1);
		}
		if (close(pipefd[1]) < 0) {
			perror("Close\n");
			exit(1);
		}
		waitpid(pid,NULL,0);
		write(1,"FIN\n",5);
		exit(0);
	}
}
