#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MAXSTRING	256

void error_y_exit(char* buff) {
	perror(buff);
	exit(1);
}

int main (int argc, char *argv[]) {
	int socketFD;
	int connectionFD;
	char buffer[MAXSTRING];
	int ret;

	if (argc != 2) error_y_exit("Usage: prServerSocket socketPath\n");
	socketFD = createSocket(argv[1]);
	if (socketFD < 0) error_y_exit("Error creating socket\n");

	connectionFD = serverConnection (socketFD);
	if (connectionFD < 0) error_y_exit("Error establishing connection \n");
	
	ret = read (connectionFD, buffer, sizeof (buffer));	
	if (ret < 0) error_y_exit("Error reading from connection\n");
	ret = write(1, buffer, strlen(buffer));
	if (ret < 0) error_y_exit("Error writing on standard output\n");
	strcpy (buffer, "You are connected!\n");
	ret = write(connectionFD, buffer, strlen (buffer));
	if (ret < 0) error_y_exit("Error writing on connection \n");

	while (ret = read (connectionFD, buffer, sizeof (buffer))) {
  		if (ret < 0) error_y_exit("Error reading from connection \n");
  		ret = write(1, buffer, ret);
		if (ret < 0) error_y_exit("Error writing on standard output\n");
	}
	closeConnection(connectionFD);
	deleteSocket(socketFD, argv[1]);
}
