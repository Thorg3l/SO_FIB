#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MAXSTRING	256

void error_y_exit(char* buff) {
	perror(buff);
	exit(1);
}

int main (int argc, char *argv[]) {
	int connectionFD;
	int ret;
	char buffer[MAXSTRING];

	if (argc != 2) error_y_exit("Usage: prClientSocket socketPath\n");
	connectionFD = clientConnection (argv[1]);
	if (connectionFD < 0) error_y_exit("Error establishing connection\n");
	strcpy (buffer, "Connected?\n");
	ret = write(connectionFD,buffer,sizeof(buffer));
	if (ret < 0) error_y_exit("Error writing on connection\n");
	ret = read (connectionFD, buffer, sizeof (buffer));
	if (ret < 0) error_y_exit("Error reading from connection\n");
	ret = write (1, buffer, ret);
	if (ret < 0) error_y_exit("Error writing on standard output \n");
	
	while (ret = read(0,buffer,sizeof(buffer))) {
		if (ret < 0) error_y_exit("Error reading from standard input\n");
		ret = write (connectionFD, buffer, ret);
		if (ret < 0) error_y_exit("Error writing on connection\n");
	}
	closeConnection(connectionFD);
}
