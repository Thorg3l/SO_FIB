#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define REGION_SIZE		4096

int *p;

void segv(int s) {
	char buff[256];
	sprintf(buff, "Dirección de p: %p\nValor de p: %p\nFinal del heap: %p\n", &p, p, sbrk(0));
	write(1, buff, strlen(buff));
	exit(1);
}

int main(int argc, char *argv[])
{
	struct sigaction sa;
	sa.sa_handler = &segv;
	sa.sa_flags = 0;
	if (sigaction(SIGSEGV, &sa, NULL) == -1) {
		perror("Error en sigaction");
		exit(1);
	}
	int i = 0;
	char buff[256];					

	sprintf( buff, "Addresses:\n");
	write(1, buff, strlen(buff));	
	sprintf( buff, "\tp: %p\n", &p);
	write(1, buff, strlen(buff));	

	p = malloc(sizeof(int));
	
	if (p == NULL) {
		sprintf(buff, "ERROR en el malloc\n");
		write(2,buff,strlen(buff));
	}

	while (1) {
		*p = i;
		sprintf( buff, "\tProgram code -- p address: %p, p value: %p, *p: %d\n",
		      &p, p, i);
		write(1, buff, strlen(buff));
		if (&p == sbrk(0)) {
			perror("Direccion invalida\n");
			exit(1);
		}	
		p++;
		i++;
	}

}
