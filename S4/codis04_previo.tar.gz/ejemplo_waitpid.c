#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>

int v_pid[10];

void error_y_exit(char *msg,int exit_status)
{
    perror(msg);
    exit(exit_status);
}

void trata_alarma(int s) {
    
}

void trata_alarma_1(int s) {
    for (int i = 0; i < 10; ++i) {
        if (v_pid[i] != -1) kill(v_pid[i], SIGKILL);
    }
    write(1, "Hijos muertos\n", 15);
}

int main(int argc,char *argv[])
{
    int pid,res;
    char buff[256];		
    int contador = 0;
    int hijos=0;
    struct sigaction sa;
    sigset_t mask;

    /* Evitamos recibir el SIGALRM fuera del sigsuspend */

    sigemptyset(&mask);
    sigaddset(&mask,SIGALRM);
    sigprocmask(SIG_BLOCK,&mask, NULL);

    for (hijos=0;hijos<10;hijos++)
    {
	sprintf(buff, "Creando el hijo numero %d\n", hijos);
	write(1, buff, strlen(buff));	
	pid=fork();
        v_pid[hijos] = pid;
	if (pid==0) /* Esta linea la ejecutan tanto el padre como el hijo */
	{
            sa.sa_handler = &trata_alarma;
    	    sa.sa_flags = SA_RESTART;
    	    sigfillset(&sa.sa_mask);
	    if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("sigaction", 1);

	    /* Escribe aqui el codigo del proceso hijo */
  	    sprintf(buff,"Hola, soy %d\n",getpid());
	    write(1, buff, strlen(buff)); 

	    alarm(5); 
	    sigfillset(&mask);
            sigdelset(&mask, SIGALRM);
            sigdelset(&mask, SIGINT);
            sigsuspend(&mask);

	    /* Termina su ejecución */
	    exit(0);
	} else if (pid<0)	
	{
	    /* Se ha producido un error */
  	    error_y_exit("Error en el fork", 1);
	}
    }
    sa.sa_handler = &trata_alarma_1;
    sa.sa_flags = SA_RESTART;
    sigfillset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("sigaction", 1);
    sigemptyset(&mask);
    sigaddset(&mask,SIGALRM);
    sigprocmask(SIG_UNBLOCK,&mask, NULL);
    while (hijos > 0)
    {
	alarm(2);
        pid=waitpid(-1,&res,0);
        int timer = alarm(0);
        if (timer != 0) {
            sprintf(buff, "La alarma ha terminado con %d segundos\n", timer);
            write(1, buff, strlen(buff));
        }
	if (WIFEXITED(res)) sprintf(buff,"Termina el proceso %d, muerte por exit\n",pid);
        else sprintf(buff,"Termina el proceso %d, muerte por signal\n",pid);
	write(1, buff, strlen(buff));
        int i = 0;
        while (i < 10) {
            if (v_pid[i] == pid) v_pid[i] = -1;
            ++i;
        } 
	hijos--;
	contador++;
    } 
    sprintf(buff,"Valor del contador %d\n", contador);
    write(1, buff, strlen(buff)); 
    return 0;
}
