#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

int segundos = 0;

void trata_signals(int s) {
	char buff[100];
	if (s == SIGALRM) segundos += 1;
	else if (s == SIGUSR1) segundos = 0;
	else if (s == SIGUSR2) {
		sprintf(buff, "%d\n", segundos);
		write(1, buff, strlen(buff));
	}
}

int main() {
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, SIGALRM);
    sigaddset(&mask, SIGUSR1);
    sigaddset(&mask, SIGUSR2);
    sigprocmask(SIG_BLOCK, &mask, NULL);
	struct sigaction sa;
	sa.sa_handler = &trata_signals;
	sa.sa_flags = SA_RESETHAND; 
    sigfillset(&sa.sa_mask); 
    if (sigaction(SIGALRM, &sa, NULL) < 0 || sigaction(SIGUSR1, &sa, NULL) || sigaction(SIGUSR2, &sa, NULL)) perror("sigaction");
   	sigfillset(&mask);
   	sigdelset(&mask, SIGALRM);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGUSR2);
    sigdelset(&mask, SIGINT);
    while (1) {
    	alarm(1);
    	sigsuspend(&mask);
    }
}
