#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>

void error_y_exit(char* msg, int exit_status) {
	perror(msg);
	exit(exit_status);
}

void muta_a_PS(char *username) {
	execlp("ps", "ps", "-u",username, (char*)NULL);
	error_y_exit("Ha fallado la mutación al ps", 1);
}

int main(int argc, char* argv[]) {
	char buff[100];
	if (argc < 2) error_y_exit("El programa recibe el nombre de usuario por parámetro\n", 2);   
	else { 
		int pid = fork();
		if (pid == 0) {
			sprintf(buff, "Hijo: mi PID es %d y el nombre de usuario es %s\n", getpid(), argv[1]);
			write(1, buff, strlen(buff));
			muta_a_PS(argv[1]);
		}
		else if (pid == -1) error_y_exit("Error en fork\n", 3);   
		else {
			sprintf(buff, "Padre: mi PID es %d\n", getpid());
			write(1, buff, strlen(buff));
		}
		while(1);
	}
}
