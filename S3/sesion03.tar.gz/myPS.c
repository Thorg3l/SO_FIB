#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>

char buff[100];

void error_y_exit(char* msg, int exit_status) {
	perror(msg);
	exit(exit_status);
}

int main(int argc, char* argv[]) {
	if (argc < 2) error_y_exit("El programa recibe el nombre de usuario por parámetro\n", 2);   
	else { 
		int pid = fork();
		if (pid == 0) sprintf(buff, "Hijo: mi PID es %d y el nombre de usuario es %s\n", getpid(), argv[1]);
		else if (pid == -1) error_y_exit("Error en fork\n", 3);   
		else sprintf(buff, "Padre: mi PID es %d\n", getpid());
		write(1, buff, strlen(buff));
		while(1);
	}
}
