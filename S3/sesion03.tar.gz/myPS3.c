#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/wait.h>

char buff[100];

void error_y_exit(char* msg, int exit_status) {
	perror(msg);
	exit(exit_status);
}

void muta_a_PS(char *username) {
	execlp("ps", "ps", "-u",username, (char*)NULL);
	error_y_exit("Ha fallado la mutación al ps", 1);
}

int main(int argc, char* argv[]) {
	if (argc < 2) error_y_exit("El programa recibe el nombre de usuario por parámetro\n", 2);   
	else { 
		for (int i = 1; i < argc; ++i) {
			int pid = fork();
			if (pid == 0) {
				sprintf(buff, "Hijo: mi PID es %d y el nombre de usuario es %s\n", getpid(), argv[i]);
				write(1, buff, strlen(buff));
				muta_a_PS(argv[i]);
			}
			else if (pid == -1) error_y_exit("Error en fork\n", 3);   
		}
		while (waitpid(-1, NULL, 0) > 0);
		char c;
		read(1,&c,sizeof(char));
		sprintf(buff, "Padre: mi PID es %d\n", getpid());
		write(1, buff, strlen(buff));
	}
}

