#!/bin/bash

make
sudo insmod myDriver1.ko
sudo insmod myDriver2.ko
