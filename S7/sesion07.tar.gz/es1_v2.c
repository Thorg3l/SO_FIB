#include <unistd.h>
#include <string.h>
#include <stdio.h>

// Este codigo escribe todos los bytes que lee de la entrada std en la salida stda

int main(){
char c;
char buffer[256];
int ret = 1;
	while(ret>0){
		ret=read(0,&buffer,256);
		write(1,&buffer,ret);
	}
}
