#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>


void int_ha(int s) {
	char buff[32];
	sprintf(buff, "Signal recibido\n");
	write(1, &buff, strlen(buff));
}

int main(){
	char buff[32];
	sigset_t mask;
	sigemptyset(&mask);
    sigaddset(&mask,SIGINT);
    sigprocmask(SIG_BLOCK,&mask, NULL);
	struct sigaction sa;
	sa.sa_handler = &int_ha;
	//sa.sa_flags = SA_RESTART;
	sa.sa_flags = 0;
	if (sigaction(SIGINT, &sa, NULL) < 0) {
		perror("Error en el sigaction\n");
		exit(1);
	}
	sigprocmask(SIG_UNBLOCK,&mask, NULL);
	char c;
	int ret = read(0, &c, sizeof(char));
	if (ret == -1) {
		if (errno == EINTR) sprintf(buff,"Interrupted system call\n");
		else sprintf(buff,"Error\n"); 
		write(1, &buff, strlen(buff));
	}
	else {
		sprintf(buff,"Read correcto\n");
		write(1, &buff, strlen(buff));
		write(1, &c, ret);
	}
}
